(function($){	

//Open the menu
    jQuery("#hamburger").click(function() {
        jQuery("#hamburgermenu").toggleClass("show")
    });


$( ".mydatepicker" ).datepicker();
	
})(jQuery) // end private scope





